#include <stdio.h>
void file1(void)
{
	printf("Control in function %s\n", __func__);
}
